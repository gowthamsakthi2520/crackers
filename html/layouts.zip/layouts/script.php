       
        <!-- jQuery first, then Bootstrap JS -->
        <script src="./assets/js/jquery.min.js"></script>
        <script src="./assets/js/bootstrap.bundle.min.js"></script>
        <!-- Subscribe From JS -->
        <script src="./assets/js/jquery.ajaxchimp.min.js"></script>
		<!-- Form Validator JS -->
        <script src="./assets/js/form-validator.min.js"></script>
        <!-- Contact JS -->
        <script src="./assets/js/contact-form-script.js"></script>
        <!-- Owl Carousel Slider JS -->
        <script src="./assets/js/owl.carousel.min.js"></script>
        <!-- Magnific Popup JS -->
        <script src="./assets/js/jquery.magnific-popup.min.js"></script>
        <!-- WOW JS -->
        <script src="./assets/js/wow.min.js"></script>
        <!-- Meanmenu JS -->
        <script src="./assets/js/meanmenu.js"></script>
        <!-- Custom JS -->
        <script src="./assets/js/custom.js"></script>