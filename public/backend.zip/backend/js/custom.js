
        function custom_noty(t, e) {
            new Noty({ type: t, layout: "topRight", timeout: 3e3, text: e, killer: !0 }).show();
            }
