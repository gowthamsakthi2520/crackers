<div class="col-md-6 mb-4">
                            <div class="card order-box">
                                <div class="home-cart-title">
                                    Product Details
                                </div>
                                <span class="checkout_render">
                                    @include('checkout.product_table')
                                </span>
                            </div>
                        </div>