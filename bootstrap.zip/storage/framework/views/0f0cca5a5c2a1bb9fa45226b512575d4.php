<table class="table">
    <thead>
        <tr>
            <th scope="col">Product</th>
            <th scope="col">Quantity</th>
            <th scope="col" class="text-right price">Price</th>
        </tr>
        <?php if(!empty($carts)): ?>
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td scope="col"><?php echo e($cart['product_name']); ?></td>
                <td scope="col" class="price"><?php echo e($cart['product_qty']); ?></td>
                <td scope="col" class="text-right price">₹<span><?php echo e($cart['price']); ?></span></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        
        <tr>
            <td scope="row" colspan="2" >SubTotal</td>
            <td class="text-right price">₹<span><?php echo e($sub_amt); ?></span></td>
        </tr>
        <tr >
            <td scope="row" colspan="2" >Offer</td>
            <td class="text-right price">₹<span><?php echo e($offer_amt); ?></span></td>
        </tr>
    </thead>
    <tbody>
        <tr  class="table-danger">
            <th scope="row" colspan="2" >Total</th>
            <th class="text-right price">₹<span><?php echo e($offer_amt + $sub_amt); ?></span></th>
        </tr>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\crackers\resources\views/checkout/product_table.blade.php ENDPATH**/ ?>