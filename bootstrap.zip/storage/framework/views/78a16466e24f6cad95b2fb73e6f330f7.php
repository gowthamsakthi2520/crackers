<?php if(session()->has('error')): ?>
<script>
	custom_noty("error", "<?php echo e(Session::get('error')); ?>");
</script>
<?php endif; ?>

<?php if(session()->has('success')): ?>
<script>
	custom_noty("success", "<?php echo e(Session::get('success')); ?>");
</script>
<?php endif; ?>

<?php if(session()->has('warning')): ?>
<script>
	custom_noty("warning", "<?php echo e(Session::get('warning')); ?>");
</script>
<?php endif; ?>

<?php if(session()->has('alert')): ?>
<script>
	custom_noty("alert", "<?php echo e(Session::get('alert')); ?>");
</script>
<?php endif; ?>

<?php if(session()->has('notification')): ?>
<script>
	custom_noty("notification", "<?php echo e(Session::get('notification')); ?>");
</script>
<?php endif; ?>

<?php if(session()->has('info')): ?>
<script>
	custom_noty("info", "<?php echo e(Session::get('info')); ?>");
</script>
<?php endif; ?>

<?php if(session()->has('information')): ?>
<script>
	custom_noty("information", "<?php echo e(Session::get('information')); ?>");
</script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\crackers\resources\views/message.blade.php ENDPATH**/ ?>