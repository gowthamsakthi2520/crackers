<div class="col-md-6 mb-4">
                            <div class="card order-box">
                                <div class="home-cart-title">
                                    Product Details
                                </div>
                                <span class="checkout_render">
                                    <?php echo $__env->make('checkout.product_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </span>
                            </div>
                        </div><?php /**PATH C:\xampp\htdocs\crackers\resources\views/checkout/checkout.blade.php ENDPATH**/ ?>