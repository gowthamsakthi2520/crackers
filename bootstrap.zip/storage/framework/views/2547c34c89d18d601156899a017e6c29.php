<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\crackers\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>