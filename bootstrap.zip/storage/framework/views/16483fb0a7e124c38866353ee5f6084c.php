                    <?php if(!empty($carts)): ?>
                         <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="home-cart-list d-flex align-items-center">
                                <div class="cart-number">
                                    <span><?php echo e($cart['product_qty']); ?></span>
                                </div>
                                <div class="cart-details">
                                    <h6 class="mb-0"><?php echo e($cart['product_name']); ?></h6>
                                    <p class="mb-0 price">₹<span><?php echo e($cart['price']); ?></span></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="home-cart-list d-flex align-items-center">
                            <div class="cart-details">
                                <h6 class="mb-0">No Item found</h6>
                            </div>
                        </div>
                    <?php endif; ?><?php /**PATH C:\xampp\htdocs\crackers\resources\views/cart/cart_list.blade.php ENDPATH**/ ?>